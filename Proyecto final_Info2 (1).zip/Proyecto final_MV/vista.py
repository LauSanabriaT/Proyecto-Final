from PyQt5.QtWidgets import  QMainWindow, QPushButton, QVBoxLayout, QWidget, QLabel, QLineEdit, QMessageBox,QDialog 
import matplotlib.pyplot as plt
from PyQt5.QtCore import Qt 
from controlador import ControladorECG

class VentanaLogin(QMainWindow):
    def __init__(self, gestor):
        super().__init__()
        self.gestor = gestor
        self.setWindowTitle("Iniciar Sesión")
        self.setGeometry(100, 100, 400, 300)

        # Layout principal
        layout = QVBoxLayout()

        self.label_usuario = QLabel("Usuario:")
        self.input_usuario = QLineEdit()
        layout.addWidget(self.label_usuario)
        layout.addWidget(self.input_usuario)

        self.label_contraseña = QLabel("Contraseña:")
        self.input_contraseña = QLineEdit()
        self.input_contraseña.setEchoMode(QLineEdit.Password)
        layout.addWidget(self.label_contraseña)
        layout.addWidget(self.input_contraseña)

        boton_login = QPushButton("Iniciar Sesión")
        boton_login.clicked.connect(self.verificar_credenciales)
        layout.addWidget(boton_login)

        boton_volver = QPushButton("Volver")
        boton_volver.clicked.connect(self.gestor.mostrar_bienvenida)
        layout.addWidget(boton_volver)

        # Configuración de layout
        contenedor = QWidget()
        contenedor.setLayout(layout)
        self.setCentralWidget(contenedor)

    def verificar_credenciales(self):
        usuario = self.input_usuario.text()
        contraseña = self.input_contraseña.text()
        if self.gestor.controlador.verificar_usuario(usuario, contraseña):
            QMessageBox.information(self, "Éxito", "Inicio de sesión exitoso")
            self.gestor.mostrar_anomalias()
        else:
            QMessageBox.warning(self, "Error", "Usuario o contraseña incorrectos")

class VentanaBienvenida(QMainWindow):
    def __init__(self, gestor):
        super().__init__()
        self.gestor = gestor  # Recibe el gestor como argumento
        self.setWindowTitle("Bienvenido")
        self.setGeometry(100, 100, 400, 300)

        # Layout principal
        layout = QVBoxLayout()

        # Widgets
        label = QLabel("Bienvenido al programa de detección de anomalías en señales ECG!!!")
        label.setAlignment(Qt.AlignCenter)
        layout.addWidget(label)

        boton_registrar = QPushButton("Registrar Usuario")
        boton_registrar.clicked.connect(self.gestor.mostrar_registro)
        layout.addWidget(boton_registrar)

        boton_login = QPushButton("Iniciar Sesión")
        boton_login.clicked.connect(self.gestor.mostrar_login)
        layout.addWidget(boton_login)

        # Configuración de layout
        contenedor = QWidget()
        contenedor.setLayout(layout)
        self.setCentralWidget(contenedor)
            


class VentanaRegistro(QMainWindow):
    def __init__(self,gestor):
        super().__init__()
        self.controlador= ControladorECG()
        self.gestor = gestor
        self.setWindowTitle("Registrar Usuario")
        self.setGeometry(100, 100, 400, 300)

        # Layout principal
        layout = QVBoxLayout()

        label = QLabel("Ingrese los datos del nuevo usuario:")
        label.setAlignment(Qt.AlignCenter)
        layout.addWidget(label)

        self.input_usuario = QLineEdit()
        self.input_usuario.setPlaceholderText("Usuario")
        layout.addWidget(self.input_usuario)

        self.input_contraseña = QLineEdit()
        self.input_contraseña.setPlaceholderText("Contraseña")
        self.input_contraseña.setEchoMode(QLineEdit.Password)
        layout.addWidget(self.input_contraseña)

        boton_registrar = QPushButton("Registrar")
        boton_registrar.clicked.connect(self.controlador.registrar_usuario)
        layout.addWidget(boton_registrar)

        boton_volver = QPushButton("Volver")
        boton_volver.clicked.connect(self.gestor.mostrar_bienvenida)
        layout.addWidget(boton_volver)

        # Configuración de layout
        contenedor = QWidget()
        contenedor.setLayout(layout)
        self.setCentralWidget(contenedor)


class VistaECGAnomalias(QMainWindow):
    def __init__(self):
        from controlador import ControladorECG
        super().__init__()
        self.controlador = ControladorECG()# Se asignará más tarde
        self.initUI()



    def initUI(self):
        self.setWindowTitle("Procesamiento de Señales ECG y Detección de Anomalías")
        self.setGeometry(100, 100, 800, 600)

        # Layout principal
        layout = QVBoxLayout()

        # Botones principales
        btn_simular = QPushButton("Simular Señal")
        btn_simular.clicked.connect(self.simular_senal)
        layout.addWidget(btn_simular)

        btn_guardar = QPushButton("Guardar Datos")
        btn_guardar.clicked.connect(self.guardar_datos)
        layout.addWidget(btn_guardar)

        # Sección de Anomalías
        self.label_anomalias = QLabel("Opciones de Detección de Anomalías")
        self.label_anomalias.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(self.label_anomalias)

        # Botón principal para mostrar opciones de anomalías
        btn_detectar_anomalias = QPushButton("Detectar Anomalías")
        btn_detectar_anomalias.clicked.connect(self.mostrar_opciones_anomalias)
        layout.addWidget(btn_detectar_anomalias)

        # Botón para guardar los datos en la base de datos
        self.guardar_db_btn = QPushButton("Guardar CSV en Base de Datos")
        self.guardar_db_btn.clicked.connect(self.guardar_en_base_datos)
        layout.addWidget(self.guardar_db_btn)

        # Label para mostrar el estado
        self.label_info = QLabel("Estado: Listo")
        layout.addWidget(self.label_info)

        # Configurar contenedor central
        container = QWidget()
        container.setLayout(layout)
        self.setCentralWidget(container)
        
        # Botón para cargar archivo
        self.cargar_btn = QPushButton("Cargar Archivo CSV")
        self.cargar_btn.clicked.connect(self.controlador.cargar_archivo_csv)
        layout.addWidget(self.cargar_btn)
        
        # Mensaje de estado
        self.estado = QLabel("")
        layout.addWidget(self.estado)
        
        # Contenedor
        container = QWidget()
        container.setLayout(layout)
        self.setCentralWidget(container)


    def simular_senal(self):
        
        """Simula una señal y la procesa."""
        self.df_senal = self.controlador.simular_senal()
        self.df_senal, self.cantidad_picos, self.df_picos = self.controlador.procesar_senal(self.df_senal)
        self.label_info.setText(f"Señal simulada y procesada con {self.cantidad_picos} picos.")
        self.graficar(self.df_senal)

    def guardar_datos(self):
        """Guarda los datos procesados en la base de datos."""
        if hasattr(self, "df_senal"):
            self.controlador.guardar_resultados(self.cantidad_picos, self.df_senal)
            self.label_info.setText("Datos guardados en la base de datos.")
        else:
            self.label_info.setText("Primero simula una señal.")
    
    def set_controlador(self, controlador):
        """Permite inyectar el controlador después de la inicialización"""
        self.controlador = controlador
    
    def guardar_en_base_datos(self):
        """
        Llama al método del controlador para guardar los datos en la base de datos.
        """
        if self.controlador is None:
            raise ValueError("No se ha configurado el controlador")
            
        self.controlador.guardar_csv()
    
    def graficar(self, df_senal):
        """Muestra un gráfico de la señal."""
        plt.figure(figsize=(10, 6))
        plt.plot(df_senal["Tiempo"], df_senal["Amplitud"], label="Señal Original")
        if "Filtrada" in df_senal.columns:
            plt.plot(df_senal["Tiempo"], df_senal["Filtrada"], label="Señal Filtrada")
        plt.legend()
        plt.title("Señal ECG")
        plt.xlabel("Tiempo")
        plt.ylabel("Amplitud")
        plt.show()

    def mostrar_opciones_anomalias(self):
        """Muestra botones para seleccionar el tipo de anomalía a analizar."""
        # Crear una ventana modal para opciones de anomalías
        self.ventana_anomalias = QDialog(self)
        self.ventana_anomalias.setWindowTitle("Opciones de Anomalías")
        self.ventana_anomalias.setGeometry(150, 150, 300, 200)

        layout_anomalias = QVBoxLayout()

        label = QLabel("Seleccione la anomalía a analizar:")
        label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout_anomalias.addWidget(label)

        # Botones de opciones
        botones_anomalias = {
            "Isquemia": self.controlador.detectar_isquemia,
            "Arritmia": self.controlador.detectar_arritmia,
            "Extrasístole": self.controlador.detectar_extrasistoles,
        }

        for nombre, funcion in botones_anomalias.items():
            boton = QPushButton(nombre)
            boton.clicked.connect(funcion)
            layout_anomalias.addWidget(boton)

        self.ventana_anomalias.setLayout(layout_anomalias)
        self.ventana_anomalias.exec()

    def detectar_isquemia(self):
        # Implementa la lógica de detección de isquemia
        resultado = self.controlador.detectar_isquemia()
        self.mostrar_resultado_isquemia(resultado)

    def detectar_arritmia(self):
        # Implementa la lógica de detección de arritmia
        resultado = self.controlador.detectar_arritmia()
        self.mostrar_resultado_arritmia(resultado)

    def detectar_extrasistoles(self):
        # Implementa la lógica de detección de extrasístoles
        resultado = self.controlador.detectar_extrasistoles()
        self.mostrar_resultado_extrasistoles(resultado)

    def mostrar_resultado_isquemia(self, resultado):
        """
        Muestra el resultado del análisis de isquemia.
        """
        QMessageBox.information(self, "Isquemia", f"Isquemia detectada: {resultado}")

    def mostrar_resultado_arritmia(self, resultado):
        """
        Muestra el resultado del análisis de arritmia.
        """
        QMessageBox.information(self, "Arritmia", f"Arritmia detectada: {resultado}")

    def mostrar_resultado_extrasistoles(self, resultado):
        """
        Muestra el resultado del análisis de extrasístoles.
        """
        QMessageBox.information(self, "Extrasístoles", f"Extrasístoles detectadas: {resultado}")

    def mostrar_error_sin_senal(self):
        """
        Muestra mensaje de error cuando no hay señal cargada.
        """
        QMessageBox.warning(self, "Advertencia", "Primero carga una señal.")

    def mostrar_mensaje(self, mensaje):
        self.estado.setText(mensaje)
