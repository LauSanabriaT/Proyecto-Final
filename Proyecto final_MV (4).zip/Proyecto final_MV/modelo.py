import mysql.connector
import pandas as pd
import numpy as np
from scipy.signal import butter, filtfilt, find_peaks
import matplotlib.pyplot as plt

class ModeloECG:
    def __init__(self, host="localhost", user="informatica2", password="abcd1234", database="proyecto_ecg"):
        self.conexion = mysql.connector.connect(
            host=host,
            user=user,
            password=password,
            database=database
        )
        self.cursor = self.conexion.cursor()
        self.data=None

    def procesar_senal(self, df_senal, frecuencia_muestreo=500):
        """
        Procesa una señal ECG para detectar picos R
        
        Args:
            df_senal (pd.DataFrame): DataFrame con la señal. Debe contener una columna 
                                    con los valores de amplitud
            frecuencia_muestreo (int): Frecuencia de muestreo en Hz. Default 500Hz
        
        Returns:
            tuple: (DataFrame con señal original y filtrada, número de picos, DataFrame con los picos)
        """
        try:
            # Verificar que el DataFrame no esté vacío
            if df_senal.empty:
                raise ValueError("El DataFrame está vacío")
                
            # Detectar la columna de amplitud
            columnas_posibles = ['Amplitud', 'amplitud', 'ECG', 'ecg', 'Señal', 'señal','signal','Signal']
            columna_amplitud = None
            
            for col in columnas_posibles:
                if col in df_senal.columns:
                    columna_amplitud = col
                    break
                    
            if columna_amplitud is None:
                # Si no encuentra ninguna columna conocida, usar la segunda columna
                # (asumiendo que la primera podría ser tiempo)
                if len(df_senal.columns) >= 2:
                    columna_amplitud = df_senal.columns[1]
                else:
                    raise ValueError("No se encontró una columna válida para la amplitud")

            # Convertir los datos a numérico si no lo son
            df_senal[columna_amplitud] = pd.to_numeric(df_senal[columna_amplitud], errors='coerce')
            
            # Verificar si hay valores nulos después de la conversión
            if df_senal[columna_amplitud].isna().any():
                raise ValueError("La señal contiene valores no numéricos")

            # Normalizar la señal
            senal_normalizada = (df_senal[columna_amplitud] - df_senal[columna_amplitud].mean()) / df_senal[columna_amplitud].std()
            
            # Diseño del filtro Butterworth
            nyquist = frecuencia_muestreo / 2
            frecuencia_corte = 40  # Hz, frecuencia típica para ECG
            w = frecuencia_corte / nyquist
            
            # Aplicar el filtro
            b, a = butter(3, w, btype='low', analog=False)
            filtrada = filtfilt(b, a, senal_normalizada)
            
            # Detección de picos adaptativa
            distancia_minima = int(frecuencia_muestreo * 0.2)  # 200ms entre picos
            altura_minima = np.mean(filtrada) + 0.5 * np.std(filtrada)
            
            picos, _ = find_peaks(filtrada, 
                                distance=distancia_minima,
                                height=altura_minima)
            
            # Crear copia del DataFrame para no modificar el original
            df_procesado = df_senal.copy()
            
            # Agregar columna filtrada
            df_procesado['Filtrada'] = filtrada
            
            # Obtener DataFrame con solo los picos
            df_picos = df_procesado.iloc[picos]
            
            return df_procesado, len(picos), df_picos
            
        except Exception as e:
            print(f"Error en el procesamiento de la señal: {str(e)}")
            # Retornar el DataFrame original sin procesar y valores nulos
            return df_senal, 0, pd.DataFrame()

    def detectar_arritmia(self, intervalos_rr):
        """Detecta arritmias basándose en los intervalos RR."""
        try:
            # Convierte los intervalos a milisegundos para un análisis más preciso
            intervalos_ms = intervalos_rr * 1000  # Asumiendo que los intervalos están en segundos
            
            # Calcula la variabilidad de los intervalos RR
            variabilidad = np.std(intervalos_ms)
            
            # Calcula la frecuencia cardíaca media
            frecuencia_cardiaca = 60 / np.mean(intervalos_rr)
            
            # Criterios de detección de arritmia
            if variabilidad > 150 or not (60 <= frecuencia_cardiaca <= 100):
                return {
                    "estado": "Arritmia detectada",
                    "variabilidad_rr": variabilidad,
                    "frecuencia_cardiaca": frecuencia_cardiaca
                }
            return {
                "estado": "Sin arritmia",
                "variabilidad_rr": variabilidad,
                "frecuencia_cardiaca": frecuencia_cardiaca
            }
        except Exception as e:
            return {"estado": f"Error en detección de arritmia: {str(e)}"}
    
    def detectar_extrasistoles(self, intervalos_rr):
        """Detecta extrasístoles basándose en intervalos RR."""
        try:
            # Convierte los intervalos a milisegundos
            intervalos_ms = intervalos_rr * 1000
            
            # Calcula el intervalo RR medio
            media_intervalos = np.mean(intervalos_ms)
            
            # Encuentra extrasístoles (intervalos significativamente más cortos)
            extrasistoles = [i for i in intervalos_ms if i < 0.6 * media_intervalos]
            
            return {
                "estado": "Extrasístoles detectadas" if extrasistoles else "Sin extrasístoles",
                "cantidad_extrasistoles": len(extrasistoles),
                "intervalos_extrasistoles": extrasistoles
            }
        except Exception as e:
            return {"estado": f"Error en detección de extrasístoles: {str(e)}"}

    def detectar_isquemia(self, senal):
        """
        Detecta isquemia según desviaciones de la línea base.
        
        Args:
        senal (pandas.DataFrame or numpy.array): Señal ECG a analizar
        
        Returns:
        dict: Resultado del análisis de isquemia
        """
        try:
            # Asegurarse de que la señal sea un array numpy
            if isinstance(senal, pd.DataFrame):
                senal = senal["Señal"].values
               
            # Calcular la línea base
            linea_base = np.mean(senal)
            
            # Definir umbrales de desviación
            umbral_desviacion = 0.2  # 20% de desviación
            
            # Detectar segmentos con desviaciones significativas
            desviaciones_positivas = senal[senal > (linea_base * (1 + umbral_desviacion))]
            desviaciones_negativas = senal[senal < (linea_base * (1 - umbral_desviacion))]
            
            return {
                "estado": "Isquemia detectada" if len(desviaciones_positivas) > 0 or len(desviaciones_negativas) > 0 else "Sin isquemia",
                "desviaciones_positivas": len(desviaciones_positivas),
                "desviaciones_negativas": len(desviaciones_negativas),
                "linea_base": linea_base
            }
        except Exception as e:
            return {"estado": f"Error en detección de isquemia: {str(e)}"}

    def registrar_usuario(self, usuario, contraseña):
        sql = "INSERT INTO usuarios (usuario, contraseña) VALUES (%s, %s)"
        self.cursor.execute(sql, (usuario, contraseña))
        self.conexion.commit()
        
    def verificar_usuario(self, usuario, contraseña):
        sql = "SELECT * FROM usuarios WHERE usuario = %s AND contraseña = %s"
        self.cursor.execute(sql, (usuario, contraseña))
        return self.cursor.fetchone() is not None

    def guardar_datos(self, cantidad_picos, df_original, df_filtrada):
        # Convertimos los DataFrames en JSON
        json_original = df_original.to_json(orient="records")
        json_filtrada = df_filtrada.to_json(orient="records")

        # Insertamos los datos en la base de datos
        sql = """
        INSERT INTO Resultados (cantidad_picos, senal_original, senal_filtrada)
        VALUES (%s, %s, %s)
        """
        self.cursor.execute(sql, (cantidad_picos, json_original, json_filtrada))
        self.conexion.commit()
        print(f"Datos guardados correctamente con ID: {self.cursor.lastrowid}")

    def cargar_datos_csv(self, file_path):
        """
        Carga un archivo CSV desde la ruta proporcionada.
        """
        try:
            if not file_path:
                raise ValueError("La ruta del archivo no puede estar vacía.")
            
            self.data = pd.read_csv(file_path)  # Cargar los datos
            print(f"Archivo cargado exitosamente desde: {file_path}")
            print(f"Datos cargados: {self.data.head()}")  # Muestra los primeros datos como verificación
            
            # Llamar a la detección de anomalías con los datos cargados
            return self.data  # Devolver los datos para que el controlador pueda usarlos
        except FileNotFoundError:
            print("Archivo no encontrado. Verifica la ruta del archivo.")
            return None
        except pd.errors.ParserError:
            print("Error al analizar el archivo CSV. Asegúrate de que tiene el formato correcto.")
            return None
        except Exception as e:
            print(f"Error inesperado al cargar el archivo: {e}")
            return None

   # def graficar_datos_csv(self, columna_x, columna_y):
   #     """
   #     Grafica dos columnas específicas del archivo CSV cargado.
   #     """
   #     if self.data is None:
   #         raise ValueError("No se ha cargado ningún archivo CSV.")
   #     
   #     if columna_x not in self.data.columns or columna_y not in self.data.columns:
   #         raise ValueError(f"Una o ambas columnas no existen en el archivo: {columna_x}, {columna_y}")
   #     
   #     plt.figure(figsize=(10, 6))
   #     plt.plot(self.data[columna_x], self.data[columna_y], label=f"{columna_x} vs {columna_y}")
   #     plt.xlabel(columna_x)
   #     plt.ylabel(columna_y)
   #     plt.title(f"Gráfico de '{columna_x}' vs '{columna_y}'")
   #     plt.legend()
   #     plt.grid(True)
   #     plt.show()

    def guardar_csv(self):
        """
        Guarda los datos cargados en una tabla MySQL.
        """
        if self.data is None:
            raise ValueError("No hay datos cargados para guardar.")
        
        try:
            print("Columnas en el DataFrame:", self.data.columns.tolist())
            
            for _, fila in self.data.iterrows():
            # Convertir los valores float64 a float Python nativo
              tiempo = float(fila['Tiempo'])
              señal = float(fila['Señal'])

              sql = "INSERT INTO Resultados CSV (Tiempo, Señal) VALUES (%s, %s)"
              self.cursor.execute(sql, (tiempo, señal))

            self.conexion.commit()
            self.conexion.close()
            
        except Exception as e:
            raise Exception(f"Error al guardar los datos: {e}")


    def cerrar_conexion(self):
        self.cursor.close()
        self.conexion.close()
   

if __name__ == "__main__":
    try:
        modelo = ModeloECG()
        print("Conexión exitosa a la base de datos.")
    except Exception as e:
        print(f"Error al conectar a la base de datos: {e}")


